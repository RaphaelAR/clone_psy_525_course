# psy-525-reproducible-research-2020
Files related to a course Rick Gilmore taught in Spring 2020 on reproducible research practices
